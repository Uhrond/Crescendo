﻿

var DistanceToHideAccueil = 2000;





var WorkSize = 0;
var ItemUse = null;
var ActiveScreen = "Accueil";