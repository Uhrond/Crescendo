﻿$(window).resize(function ()
{
    waitForFinalEvent(function ()
    {
        location.reload();
    }, 500, "id");
});
/* Fonction permettant d'attendre la fin du resize de la fenetre */
var waitForFinalEvent = (function ()
{
    var timers = {};
    return function (callback, ms, uniqueId)
    {
        if (!uniqueId)
        {
            uniqueId = "Don't call this twice without a uniqueId";
        }
        if (timers[uniqueId])
        {
            clearTimeout(timers[uniqueId]);
        }
        timers[uniqueId] = setTimeout(callback, ms);
    };
})();
 
$(".PlayCard").click(function ()
{
    ActiveScreen = "Galerie";
    $(".ContainerGalerie").show(1, function ()
    {
        $('html, body').animate({ scrollTop: 0 }, 'slow');
        var $card = $(".card");
        $card.each(function (k, v)
        {
            var el = $(this);
            setTimeout(function ()
            {
                el.animate({
                    top: el.position().top - $(".ContainerAccueil").height()
                }, 1500, "easeInOutBack", function ()
                {
                    if (k == $card.length - 1)
                    {
                        $(this).hide();
                        $(".ContainerAccueil").hide();
                    } else
                    {
                        $(this).hide();
                    }
                });
            }, k * 25);
        })

        setTimeout(
          function ()
          {
              var $item = $(".item, .GalerieTitle");
              $item.each(function (k, v)
              {
                  $(this).show();
                  var el = $(this);
                  setTimeout(function ()
                  {
                      el.animate({
                          top: el.position().top - $(".ContainerAccueil").height()
                      }, 1500, "easeOutBack");
                  }, k * 25);
              });
          }, 850);

    });
});


$(".PlayCardBack").click(function ()
{
    ActiveScreen = "Accueil";
    $(".ContainerAccueil").show(1, function ()
    {
        $('html, body').animate({ scrollTop: 0 }, 'slow');
        setTimeout(
            function ()
            {
                $(".card").each(function (k, v)
                {
                    $(this).show();
                    var el = $(this);
                    setTimeout(function ()
                    {
                        el.animate({
                            top: el.position().top + $(".ContainerAccueil").height()
                        }, 1500, "easeOutBack");
                    }, k * 25);
                });
            }, 750);

        var $item = $(".item, .GalerieTitle");
        $item.each(function (k, v)
        {
            var el = $(this);
            setTimeout(function ()
            {
                el.animate({
                    top: el.position().top + $(".ContainerAccueil").height()
                }, 1500, "easeInOutBack", function ()
                {
                    if (k == $item.length - 1)
                    {
                        $(this).hide();
                        $(".ContainerGalerie").hide();
                        window.scrollTo(0, 0);
                    } else
                    {
                        $(this).hide();
                    }
                });
            }, k * 25);
        });
    });
});



