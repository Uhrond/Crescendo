﻿$(window).ready(function ()
{
    $(".SplashScreen").show();
    $(".gray").hide();
    OrganiseAccueil();

    LoadPicture();
    OrganiseGalerie();


    $(".ContainerGalerie").hide();
    $(".SplashScreen").hide();
});