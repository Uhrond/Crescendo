﻿function OrganiseAccueil()
{
    var GridNbCol = 5;
    var GridPadding = 8;
    var GridMargin = 20; /* En pourcentage */

    if ($(window).width() < 1600)
    {
        GridMargin = 15;
        GridNbCol = 5;
        GridPadding = 6;
    }
     
    if ($(window).width() < 1200)
    {
        GridMargin = 5;
        GridNbCol = 5;
        GridPadding = 4;
    }

    if ($(window).width() < 900)
    {
        GridMargin = 10;
        GridNbCol = 3;
        GridPadding = 2;
    }
    if ($(window).width() < 700)
    {
        GridMargin = 5;
        GridNbCol = 3;
        GridPadding = 2;
    }

    GridMargin = ($(window).width() * GridMargin) / 100;

    var GridTop = 150;

    var GridSize = ($(window).width() - 2 * GridMargin - (GridNbCol + 1) * GridPadding) / GridNbCol;

    if (GridSize < 170)
        GridSize = 170;

    var RowSize = GridSize;

    $(".ContainerAccueil").height(0);

    var widthFirstCol = GridSize;

    if (GridSize > 200)
    {
        widthFirstCol = 200;
    }

    var left = widthFirstCol + GridMargin + GridPadding;
    var top = GridTop + GridPadding;

    $(".card[data-position='1']").each(function (index, el)
    {
        var ColNb = $(this).data("col");
        var RowNb = $(this).data("row");

        $(this).css({
            "top": top + GridPadding,
            "left": GridMargin + GridPadding,
            "width": widthFirstCol * ColNb - 2 * GridPadding,
            "height": widthFirstCol * RowNb - 2 * GridPadding
        });
        top = top + RowSize * RowNb + GridPadding;
    });

    top = GridTop + GridPadding;
    GridSize = ($(window).width() - 2 * GridMargin - widthFirstCol - GridNbCol * GridPadding) / (GridNbCol - 1);

    WorkSize = GridSize;

    $(".card").not("[data-position='1']").each(function (index, el)
    {
        var ColNb = $(this).data("col");
        var RowNb = $(this).data("row");

        var b = true;
        while (ColNb > GridNbCol - 1)
        {
            ColNb = ColNb - 1;
            if (b)
            {
                RowNb++;
                b = !b;
            }
            else
            {
                b = !b;
            }
        }

        $(this).css({
            "top": top + GridPadding,
            "left": left + GridPadding,
            "width": GridSize * ColNb - 2 * GridPadding,
            "height": RowSize * RowNb - 2 * GridPadding
        });

        left = left + GridSize * ColNb;

        if (left > $(window).width() - 2 * GridMargin)
        {
            top = top + RowSize * RowNb;
            left = widthFirstCol + GridMargin + GridPadding;
        }

        $(".ContainerAccueil").height(top + RowSize * RowNb);

        if (ActiveScreen == "Galerie")
            $(".ContainerAccueil").hide();

    });

}