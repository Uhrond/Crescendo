﻿$(document).ready(function ()
{
    new jPlayerPlaylist({
        jPlayer: "#jquery_jplayer_1",
        cssSelectorAncestor: "#jp_container_1"
    }, [
        {
            title: "La biguine à Coco<br/><p class='auteur'>de Carles Belda</p>",
            mp3: "Playlist/La biguine à Coco.mp3",
            oga: ""
        },
        {
            title: "Ao Amanhecer<br/>",
            mp3: "Playlist/Ao Amanhecer.mp3",
            oga: ""
        },

    ], {
        swfPath: "../../dist/jplayer",
        supplied: "oga, mp3",
        wmode: "window",
        useStateClassSkin: true,
        autoBlur: false,
        smoothPlayBar: true,
        keyEnabled: true
    });
});