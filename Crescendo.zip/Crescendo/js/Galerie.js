﻿function OrganiseGalerie()
{
    var GridNbCol = 6;
    var GridPadding = 10;
    var GridMargin = 15; /* En pourcentage */

    var gridPaddingBottom = GridPadding
    if ($(window).width() < 1600)
    {
        GridMargin = 15;
        GridNbCol = 3;
        GridPadding = 8;
        gridPaddingBottom = 8;
    }

    if ($(window).width() < 1000)
    {
        GridMargin = 10;
        GridNbCol = 2;
        GridPadding = 6;
        gridPaddingBottom = 6;
    }

    if ($(window).width() < 500)
    {
        GridMargin = 5;
        GridNbCol = 1;
        GridPadding = 0;
        gridPaddingBottom = 4;
    }
     
    var GridTop = 150;

    if (ActiveScreen == "Accueil")
        GridTop = 150 + $(".ContainerAccueil").height();

    var ColArray = new Array(GridNbCol);
    var GridSize = ($(window).width() - ($(window).width() * GridMargin * 2) / 100) / GridNbCol;
    var RowSize = GridSize / 4 - 2 * GridPadding;

    $(".ContainerGalerie").height(0);
    for (i = 0; i < ColArray.length; i++)
    {
        ColArray[i] = GridTop;
    }

    var _left = ($(window).width() * GridMargin) / 100 - 2 * GridPadding;
    var left = _left;
    var ColActive = 0;
    var id = "0";
    $(".item, .GalerieTitle").each(function (index, el)
    {

        if ($(this).hasClass("item"))
        {
            id++;
            var ColNb = $(this).data("col");
            var RowNb = $(this).data("row");

            $(this).css({
                "top": ColArray[ColActive],
                "left": left,
                "width": GridSize * ColNb - 2 * GridPadding + (ColNb - 1) * 2 * GridPadding,
                "height": RowSize * RowNb - 2 * GridPadding + (RowNb - 1) * 2 * GridPadding
            });

            $(this).data("top", ColArray[ColActive] - $(".ContainerAccueil").height());
            $(this).data("left", left);
            $(this).data("width", GridSize * ColNb - 2 * GridPadding + (ColNb - 1) * 2 * GridPadding);
            $(this).data("height", RowSize * RowNb - 2 * GridPadding + (RowNb - 1) * 2 * GridPadding);
            $(this).attr('data-ordre', id);

            left = left + GridSize * ColNb + 2 * GridPadding + (ColNb - 1) * 2 * GridPadding;

            for (i = 0; i < ColNb; i++)
            {
                var g = ColArray[ColActive + i] + RowSize * RowNb + 2 * gridPaddingBottom + (RowNb - 1) * 2 * gridPaddingBottom;
                ColArray[ColActive + i] = g;
                if ($(".ContainerGalerie").height() < g - $(".ContainerAccueil").height())
                    $(".ContainerGalerie").height(g - $(".ContainerAccueil").height());
            }
            ColActive = ColActive + ColNb;
            if (left >= GridSize * GridNbCol + ($(window).width() * GridMargin) / 100)
            {
                ColActive = 0;
                left = _left;
            }
        }
        else
        {
            var maxTop = 0;
            for (i = 0; i < ColArray.length; i++)
            {
                if (ColArray[i] > maxTop)
                    maxTop = ColArray[i];
            }
            for (i = 0; i < ColArray.length; i++)
            {
                ColArray[i] = maxTop + 60;
            }
            $(this).css({
                "top": maxTop
            });
        }
    });
}


function LoadPicture()
{
    
    $.ajax({
        url: 'LoadPicture.php',
        type: 'GET',
        dataType: 'html',
        success: function (html, statut)
        {

            $(".ContainerItem").html(html);
        },
        error: function (resultat, statut, erreur)
        {
            alert(resultat);
        },
        async: false
    });

    
    $(".item:not(.back)").each(function (index, el)
    {
        if ($(this).data("img") != "")
        {
            $(this).css({
                "background-image": "url('" + $(this).data("img") + "')",
                "background-size": "cover",
                "background-position": "center",
                "background-repeat": "no-repeat"
            });
        }
        else
        {
            $(this).css({
                "background-color": "#333333"
            });
        }
    });
}