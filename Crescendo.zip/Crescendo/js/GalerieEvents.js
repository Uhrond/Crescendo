﻿$("body").on('click', '.img', function () {
    ItemUse = $(this);

    var ratio = $(this).width() / $(this).height();

    height = $(window).height() * 0.7;
    width = height * ratio;

    $(this).css({ "z-index": 100 });

    var rotate = -$(this).data("rotate");

    $(this).addClass('imgActive');
    $(this).animate({
        "top": $(window).height() / 2 - height / 2,
        "left": $(window).width() / 2 - width / 2,
        "width": width,
        "height": height,
        "myRotationProperty": rotate
    }, {
        duration: 500,
        step: function (now, tween) {
            if (tween.prop === "myRotationProperty") {
                now = now = now / 2 - rotate / 2;;
                $(this).css('-webkit-transform', 'rotate(' + now + 'deg)');
                $(this).css('-moz-transform', 'rotate(' + now + 'deg)');
                // add Opera, MS etc. variants
                $(this).css('transform', 'rotate(' + now + 'deg)');
            }
        }
    }, function () {
        $("body").append("<div class='close'></div>");
        $(".close").css({
            "background-image": "url(Images/CloseShade.svg)",
            "background-size": "auto 95%",
            "background-position": "center",
            "background-repeat": "no-repeat",
            "cursor": "pointer",
            "width": 70,
            "height": 70,
            "z-index": "100",
            "position": "absolute",
            "top": $(this).position().top - 80,
            "left": $(window).width() / 2 + $(this).width() / 2
        });

    });
    /* Ajout controles suivant /précédent */
    $("body").append("<div class='next'></div>");
    $(".next").css({
        "background-image": "url(Images/NextShade.svg)",
        "background-size": "auto 95%",
        "background-position": "center",
        "background-repeat": "no-repeat",
        "cursor": "pointer",
        "width": 70,
        "height": 70,
        "z-index": "100",
        "position": "absolute",
        "top": $(window).height() / 2 + $(document).scrollTop() - 35,
        "right": 0
    });

    $("body").append("<div class='past'></div>");
    $(".past").css({
        "background-image": "url(Images/PastShade.svg)",
        "background-size": "auto 95%",
        "background-position": "center",
        "background-repeat": "no-repeat",
        "cursor": "pointer",
        "width": 70,
        "height": 70,
        "z-index": "100",
        "position": "absolute",
        "top": $(window).height() / 2 + $(document).scrollTop() - 35,
        "left": 0
    });

    if ($(this).data("ordre") == 2)
        $(".past").hide();

    if ($(this).data("ordre") == $(".item").length)
        $(".next").hide();


    $(this).removeClass("item");
    $(this).addClass("itemActive");
    $(".gray").show();
    $(".gray").animate({
        "opacity": 1
    }, 500);
});



$(document).click(function (event) {
    if (!$(event.target).closest('.itemActive').length &&
        !$(event.target).closest('.next').length &&
        !$(event.target).closest('.past').length) {
        if ($('.itemActive').is(":visible")) {
            var rotate = ItemUse.data("rotate");
            ItemUse.animate({
                "top": ItemUse.data("top"),
                "left": ItemUse.data("left"),
                "width": ItemUse.data("width"),
                "height": ItemUse.data("height"),
                "z-index": "1",
                "myRotationProperty": rotate
            }, {
                duration: 500,
                step: function (now, tween) {
                    if (tween.prop === "myRotationProperty") {
                        now = now / 2 + rotate / 2;
                        $(this).css('-webkit-transform', 'rotate(' + now + 'deg)');
                        $(this).css('-moz-transform', 'rotate(' + now + 'deg)');
                        // add Opera, MS etc. variants
                        $(this).css('transform', 'rotate(' + now + 'deg)');
                    }
                }
            });

            ItemUse.removeClass('imgActive');
            ItemUse.removeClass("itemActive");
            ItemUse.addClass("item");

            $(".gray").hide();
            $(".next").remove();
            $(".past").remove();
            $(".close").remove();
            $(".gray").animate({
                "opacity": 0
            }, 500);


        }
    }
})


$("body").on('click', '.next', function () {
    $(".past").show();
    $(".close").fadeOut("slow", function () { this.remove(); });
    var id = parseInt(ItemUse.data("ordre"));
    if (id == $(".item").length + 1) {
        return;
    }
    else if (id == $(".item").length) {
        $(".next").hide();
        id = id + 1;
    }
    else {
        $(".next").show();
        id = id + 1;
    }

    var rotate = ItemUse.data("rotate");
    ItemUse.animate({
        "top": ItemUse.data("top"),
        "left": ItemUse.data("left"),
        "width": ItemUse.data("width"),
        "height": ItemUse.data("height"),
        "myRotationProperty": rotate
    }, {
        duration: 250,
        step: function (now, tween) {
            if (tween.prop === "myRotationProperty") {
                now = now / 2 + rotate / 2;
                $(this).css('-webkit-transform', 'rotate(' + now + 'deg)');
                $(this).css('-moz-transform', 'rotate(' + now + 'deg)');
                // add Opera, MS etc. variants
                $(this).css('transform', 'rotate(' + now + 'deg)');
            }
        }
    });
    ItemUse.removeClass('imgActive');
    ItemUse.removeClass("itemActive");
    ItemUse.addClass("item");
    ItemUse.css({ "z-index": 1 });


    ItemUse = $('[data-ordre="' + id + '"]');

    var ratio = ItemUse.width() / ItemUse.height();

    height = $(window).height() * 0.7;
    width = height * ratio;

    ItemUse.css({ "z-index": 100 });
    ItemUse.css('filter', 'none');
    var rotate = -$(this).data("rotate");
    ItemUse.animate({
        "top": $(window).height() / 2 - height / 2 + $(document).scrollTop(),
        "left": $(window).width() / 2 - width / 2,
        "width": width,
        "height": height,
        "myRotationProperty": rotate
    }, {
        duration: 250,
        step: function (now, tween) {
            if (tween.prop === "myRotationProperty") {
                now = now = now / 2 - rotate / 2;;
                $(this).css('-webkit-transform', 'rotate(' + now + 'deg)');
                $(this).css('-moz-transform', 'rotate(' + now + 'deg)');
                // add Opera, MS etc. variants
                $(this).css('transform', 'rotate(' + now + 'deg)');
            }
        }
    }, function () {
        $("body").append("<div class='close'></div>");
        $(".close").css({
            "background-image": "url(Images/CloseShade.svg)",
            "background-size": "auto 95%",
            "background-position": "center",
            "background-repeat": "no-repeat",
            "cursor": "pointer",
            "width": 70,
            "height": 70,
            "z-index": "100",
            "position": "absolute",
            "top": ItemUse.position().top - 80,
            "left": $(window).width() / 2 + ItemUse.width() / 2
        });
    });
    ItemUse.addClass('imgActive');
    ItemUse.removeClass("item");
    ItemUse.addClass("itemActive");
});

$("body").on('click', '.past', function () {
    $(".next").show();
    $(".close").fadeOut("slow", function () { this.remove(); });
    var id = parseInt(ItemUse.data("ordre"));
    if (id == 2) {
        return;
    }
    else if (id == 3) {
        $(".past").hide();
        id = id - 1;
    }
    else {
        $(".next").show();
        id = id - 1;
    }

    var rotate = ItemUse.data("rotate");
    ItemUse.animate({
        "top": ItemUse.data("top"),
        "left": ItemUse.data("left"),
        "width": ItemUse.data("width"),
        "height": ItemUse.data("height"),
        "myRotationProperty": rotate
    }, {
        duration: 250,
        step: function (now, tween) {
            if (tween.prop === "myRotationProperty") {
                now = now / 2 + rotate / 2;
                $(this).css('-webkit-transform', 'rotate(' + now + 'deg)');
                $(this).css('-moz-transform', 'rotate(' + now + 'deg)');
                // add Opera, MS etc. variants
                $(this).css('transform', 'rotate(' + now + 'deg)');
            }
        }
    });
    ItemUse.removeClass('imgActive');
    ItemUse.removeClass("itemActive");
    ItemUse.addClass("item");
    ItemUse.css({ "z-index": 1 });


    ItemUse = $('[data-ordre="' + id + '"]');

    var ratio = ItemUse.width() / ItemUse.height();

    height = $(window).height() * 0.7;
    width = height * ratio;

    ItemUse.css({ "z-index": 100 });

    ItemUse.css('filter', 'none');
    var rotate = -$(this).data("rotate");
    ItemUse.animate({
        "top": $(window).height() / 2 - height / 2 + $(document).scrollTop(),
        "left": $(window).width() / 2 - width / 2,
        "width": width,
        "height": height,
        "myRotationProperty": rotate
    }, {
        duration: 250,
        step: function (now, tween) {
            if (tween.prop === "myRotationProperty") {
                now = now = now / 2 - rotate / 2;;
                $(this).css('-webkit-transform', 'rotate(' + now + 'deg)');
                $(this).css('-moz-transform', 'rotate(' + now + 'deg)');
                // add Opera, MS etc. variants
                $(this).css('transform', 'rotate(' + now + 'deg)');
            }
        }
    }, function () {
        $("body").append("<div class='close'></div>");
        $(".close").css({
            "background-image": "url(Images/CloseShade.svg)",
            "background-size": "auto 95%",
            "background-position": "center",
            "background-repeat": "no-repeat",
            "cursor": "pointer",
            "width": 70,
            "height": 70,
            "z-index": "100",
            "position": "absolute",
            "top": ItemUse.position().top - 80,
            "left": $(window).width() / 2 + ItemUse.width() / 2
        });
    });
    ItemUse.addClass('imgActive');
    ItemUse.removeClass("item");
    ItemUse.addClass("itemActive");

});