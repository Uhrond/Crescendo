<?php
$path = "Ressources Photos";

$directories = glob($path . '/*', GLOB_ONLYDIR);

usort( $directories, function( $a, $b ) { return filemtime($a) - filemtime($b); } );

foreach($directories as $directory) {

	echo "<div class='GalerieTitle'>" . substr($directory, strpos($directory, "/") + 1, strlen($directory))  . "</div>";

	$files = array_diff(scandir($directory), array('.', '..'));
	foreach($files as $file) {
		$ext = strtolower(pathinfo($directory . "/" . $file, PATHINFO_EXTENSION));

		if($ext == "jpg" or $ext == "png")
		{
			list($width, $height) = getimagesize($directory . "/" . $file);

			if($width > $height)
				$ratio = $width / $height + 1;
			else
				$ratio = $height/$width * 4;

			echo "<div class='item' data-img='" . $directory . "/" . $file . "' data-col='1' data-row='" . ceil($ratio) . "'></div>";
		}
	}
}
?>